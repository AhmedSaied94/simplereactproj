import React from "react";
import 'bootstrap/dist/css/bootstrap.min.css';
import { Container } from "react-bootstrap";
import Navi from "./Navi";
import Login from "./Login";
import Gallery from "./Gallery";
import Todo from "../Todo/Todo"
import PhoneBook from "../PhoneBook/PhoneBook"
import Reg from "./Reg";

export default class Day3 extends(React.Component){

  constructor(){
    super();
    this.state = {curScr:"login"}
  }

  chgScr=(cur)=>{
    this.setState({curScr:cur})
  }

  render(){

    return <Container fluid>
      <Navi chgScr={this.chgScr}/>
      <Container>
        {this.state.curScr === "login" && <Login chgScr={this.chgScr}/>}
        {this.state.curScr === "gallery" && <Gallery />}
        {this.state.curScr === "todo" && <Todo />}
        {this.state.curScr === "phoneBook" && <PhoneBook />}
        {this.state.curScr === "register" && <Reg chgScr={this.chgScr}/>}
      </Container>
    </Container>
  }
}
