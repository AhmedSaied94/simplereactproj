import React from "react";
import 'bootstrap/dist/css/bootstrap.min.css';

export default class Reg extends(React.Component){
    constructor(){
        super();
        this.state = {
            
            
            email:"",
            password:"", 
            url:"",
            upJson:"",
            msg:"We'll never share your email with anyone else."
        }
        
    }

    setEmail=(e)=>{
        this.setState({email:e.target.value})
    }

    setPass=(e)=>{
        this.setState({password:e.target.value})
    }

    log=(e)=>{
        e.preventDefault();

            
            let obj = {
                "email":this.state.email,
                "password":this.state.password
            }
            
            this.setState({upJson:JSON.stringify(obj)})
            this.setState({url:"https://reqres.in/api/login"})

            fetch(this.state.url,{
                method:"POST",
                headers:{'content-type':"application/json"},
                body:this.state.upJson
            }).then((res)=>{
                return res.json();
            }).then((json)=>{
                console.log(json)
                
                if(json.token){          
                    this.props.chgScr("gallery")
                    
                }else{
                    this.setState({msg:json.error})

                }
                
            }) 

    }
    render(){
        return <div style={{maxWidth:"800px"}} className="border border-primary rounded mt-5 mx-auto p-3">
            <form className="row g-3" method="POST" onSubmit={this.log}>
                <div className="col-md-6">
                    <label for="inputEmail4" className="form-label">Email</label>
                    <input type="email" className="form-control" id="inputEmail4" onChange={this.setEmail} value={this.state.email}/>
                </div>
                <div className="col-md-6">
                    <label for="inputPassword4" className="form-label">Password</label>
                    <input type="password" className="form-control" id="inputPassword4" onChange={this.setPass} value={this.state.password}/>
                </div>
                <div id="emailHelp" className="form-text col-12" style={{color:this.state.msg==="We'll never share your email with anyone else."?"#6c757d":"red"}}>{this.state.msg}</div>
                <div className="col-12">
                    <label for="inputAddress" className="form-label">Address</label>
                    <input type="text" className="form-control" id="inputAddress" placeholder="1234 Main St"/>
                </div>
                <div className="col-12">
                    <label for="inputAddress2" className="form-label">Address 2</label>
                    <input type="text" className="form-control" id="inputAddress2" placeholder="Apartment, studio, or floor"/>
                </div>
                <div className="col-md-6">
                    <label for="inputCity" className="form-label">City</label>
                    <input type="text" className="form-control" id="inputCity"/>
                </div>
                <div className="col-md-4">
                    <label for="inputState" className="form-label">State</label>
                    <select id="inputState" className="form-select">
                    <option selected>Choose...</option>
                    <option>...</option>
                    </select>
                </div>
                <div className="col-md-2">
                    <label for="inputZip" className="form-label">Zip</label>
                    <input type="text" className="form-control" id="inputZip"/>
                </div>
                <div className="col-12">
                    <div className="form-check">
                    <input className="form-check-input" type="checkbox" id="gridCheck"/>
                    <label className="form-check-label" for="gridCheck">
                        Check me out
                    </label>
                    </div>
                </div>
                <div className="col-12">
                    <button type="submit" className="btn btn-primary">Sign Up</button>
                </div>
            </form>
        </div>
    }
}